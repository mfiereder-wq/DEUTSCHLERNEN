import { Level } from '@/data/vocabulary';

// Satzergänzungs-Übungen
export interface SentenceExercise {
  id: string;
  level: Level;
  category: string;
  sentence: string;           // "Ich ____ jeden Morgen um 7 Uhr."
  translation: string;
  correctAnswer: string;      // "stehe auf"
  options: string[];          // ["stehe auf", "steht auf", "aufstehe", "stehen auf"]
  hint?: string;
  grammarTopic?: string;
}

export const sentenceExercises: SentenceExercise[] = [
  // A2 Sätze
  {
    id: 'se-a2-001',
    level: 'A2',
    category: 'alltag',
    sentence: 'Ich _____ jeden Morgen um 7 Uhr.',
    translation: 'Eu levanto todas as manhãs às 7 horas.',
    correctAnswer: 'stehe auf',
    options: ['stehe auf', 'steht auf', 'aufstehe', 'stehen auf'],
    hint: 'Verbo separável: o prefixo fica no final da frase.',
    grammarTopic: 'Satzklammer'
  },
  {
    id: 'se-a2-002',
    level: 'A2',
    category: 'alltag',
    sentence: '_____ Sie mir bitte sagen, wo der Bahnhof ist?',
    translation: 'O senhor pode me dizer onde fica a estação de trem?',
    correctAnswer: 'Können',
    options: ['Können', 'Kann', 'Könnte', 'Wollen'],
    hint: 'Verbo modal para uma pergunta educada.',
    grammarTopic: 'Modalverben'
  },
  {
    id: 'se-a2-003',
    level: 'A2',
    category: 'einkaufen',
    sentence: 'Ich möchte ein _____ Wasser, bitte.',
    translation: 'Eu gostaria de uma garrafa de água, por favor.',
    correctAnswer: 'Flasche',
    options: ['Flasche', 'Glas', 'Tasse', 'Becher'],
    hint: 'Qual palavra combina com água?',
    grammarTopic: 'Akkusativ'
  },
  {
    id: 'se-a2-004',
    level: 'A2',
    category: 'gesundheit',
    sentence: 'Ich habe einen Termin _____ Arzt.',
    translation: 'Tenho uma consulta médica.',
    correctAnswer: 'beim',
    options: ['beim', 'zum', 'im', 'am'],
    hint: 'beim = bei + dem',
    grammarTopic: 'Präpositionen'
  },
  {
    id: 'se-a2-005',
    level: 'A2',
    category: 'wohnung',
    sentence: 'Die Wohnung ist sehr _____ eingerichtet.',
    translation: 'O apartamento está decorado de forma muito aconchegante.',
    correctAnswer: 'gemütlich',
    options: ['gemütlich', 'gemütliche', 'gemütliches', 'gemütlicher'],
    hint: 'Advérbio - como está decorado?',
    grammarTopic: 'Adjektivendungen'
  },
  {
    id: 'se-a2-006',
    level: 'A2',
    category: 'verkehr',
    sentence: 'Entschuldigung, wie _____ ich zum Bahnhof?',
    translation: 'Com licença, como chego à estação de trem?',
    correctAnswer: 'komme',
    options: ['komme', 'kommt', 'kommst', 'kommen'],
    hint: 'Forma "ich" de kommen.',
    grammarTopic: 'Konjugation'
  },
  {
    id: 'se-a2-007',
    level: 'A2',
    category: 'alltag',
    sentence: 'Gestern _____ ich im Kino.',
    translation: 'Ontem eu estava no cinema.',
    correctAnswer: 'war',
    options: ['war', 'bin', 'warst', 'ist'],
    hint: 'Passado de sein.',
    grammarTopic: 'Präteritum'
  },
  {
    id: 'se-a2-008',
    level: 'A2',
    category: 'beruf',
    sentence: 'Ich _____ heute viel Arbeit.',
    translation: 'Eu tenho muito trabalho hoje.',
    correctAnswer: 'habe',
    options: ['habe', 'hat', 'haben', 'hast'],
    hint: 'Forma "ich" de haben.',
    grammarTopic: 'Konjugation'
  },

  // B1 Sätze
  {
    id: 'se-b1-001',
    level: 'B1',
    category: 'beruf',
    sentence: 'Ich habe mich um die Stelle _____ Siemens beworben.',
    translation: 'Candidatei-me para a vaga na Siemens.',
    correctAnswer: 'bei',
    options: ['bei', 'in', 'von', 'zu'],
    hint: 'sich bewerben bei + Dativ',
    grammarTopic: 'Verben mit Präpositionen'
  },
  {
    id: 'se-b1-002',
    level: 'B1',
    category: 'umwelt',
    sentence: 'Es ist wichtig, umweltfreundliche Produkte _____ kaufen.',
    translation: 'É importante comprar produtos ecológicos.',
    correctAnswer: 'zu',
    options: ['zu', 'um', 'für', 'ohne'],
    hint: 'Infinitivo com zu',
    grammarTopic: 'Infinitivsätze'
  },
  {
    id: 'se-b1-003',
    level: 'B1',
    category: 'freizeit',
    sentence: 'Das Konzert _____ am nächsten Samstag statt.',
    translation: 'O show acontecerá no próximo sábado.',
    correctAnswer: 'findet',
    options: ['findet', 'gefunden', 'fand', 'finden'],
    hint: 'Presente de stattfinden.',
    grammarTopic: 'Konjugation'
  },
  {
    id: 'se-b1-004',
    level: 'B1',
    category: 'beruf',
    sentence: 'Wer ist _____ die Planung verantwortlich?',
    translation: 'Quem é responsável pelo planejamento?',
    correctAnswer: 'für',
    options: ['für', 'von', 'mit', 'bei'],
    hint: 'verantwortlich sein für + Akkusativ',
    grammarTopic: 'Verben mit Präpositionen'
  },
  {
    id: 'se-b1-005',
    level: 'B1',
    category: 'alltag',
    sentence: 'Ich hatte keine Zeit, _____ konnte ich nicht zum Training gehen.',
    translation: 'Eu não tinha tempo, por isso não pude ir ao treino.',
    correctAnswer: 'deshalb',
    options: ['deshalb', 'trotzdem', 'dennoch', 'aber'],
    hint: 'Indicar uma razão',
    grammarTopic: 'Konjunktionen'
  },
  {
    id: 'se-b1-006',
    level: 'B1',
    category: 'alltag',
    sentence: 'Wenn ich mehr Geld _____, würde ich reisen.',
    translation: 'Se eu tivesse mais dinheiro, viajaria.',
    correctAnswer: 'hätte',
    options: ['hätte', 'hatte', 'habe', 'haben würde'],
    hint: 'Konjunktiv II de haben',
    grammarTopic: 'Konjunktiv II'
  },
  {
    id: 'se-b1-007',
    level: 'B1',
    category: 'beruf',
    sentence: 'In dem Lebenslauf _____ alle Erfahrungen aufgelistet.',
    translation: 'No currículo, todas as experiências estão listadas.',
    correctAnswer: 'werden',
    options: ['werden', 'werde', 'wird', 'worden'],
    hint: 'Passivo no presente',
    grammarTopic: 'Passiv'
  },
  {
    id: 'se-b1-008',
    level: 'B1',
    category: 'alltag',
    sentence: 'Ich habe mich _____ Deutsch zu lernen.',
    translation: 'Decidi aprender alemão.',
    correctAnswer: 'entschieden',
    options: ['entschieden', 'entscheide', 'entschied', 'entscheiden'],
    hint: 'Perfeito de entscheiden',
    grammarTopic: 'Perfekt'
  }
];

// Kurzgeschichten mit Fragen
export interface StoryQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;  // Index of correct answer
}

export interface Story {
  id: string;
  title: string;
  level: Level;
  category: string;
  text: string;
  translation: string;
  questions: StoryQuestion[];
  duration: number; // geschätzte Lesezeit in Minuten
}

export const stories: Story[] = [
  {
    id: 'story-a2-001',
    title: 'Der neue Job',
    level: 'A2',
    category: 'beruf',
    text: `Maria ist 28 Jahre alt und kommt aus Spanien. Seit drei Monaten lebt sie in Deutschland. Sie sucht einen Job.

Jeden Morgen trinkt Maria Kaffee und liest die Zeitung. Eines Tages sieht sie eine Anzeige: "Wir suchen eine Sekretärin. Bitte rufen Sie an!"

Maria ruft sofort an. Am nächsten Tag hat sie ein Vorstellungsgespräch. Sie ist sehr nervös, aber sie ist auch freundlich und höflich.

Der Chef fragt: "Können Sie gut Deutsch sprechen?" Maria antwortet: "Ja, ich lerne seit zwei Jahren Deutsch."

Nach einer Woche bekommt Maria eine E-Mail: "Sie haben den Job!" Maria ist sehr glücklich. Am Montag fängt sie an zu arbeiten.`,
    translation: `Maria tem 28 anos e vem da Espanha. Há três meses ela vive na Alemanha. Ela está procurando um emprego.

Todas as manhãs Maria toma café e lê o jornal. Um dia ela vê um anúncio: "Procuramos uma secretária. Por favor, ligue!"

Maria liga imediatamente. No dia seguinte ela tem uma entrevista de emprego. Ela está muito nervosa, mas também é simpática e educada.

O chefe pergunta: "Você fala bem alemão?" Maria responde: "Sim, aprendo alemão há dois anos."

Depois de uma semana Maria recebe um e-mail: "Você conseguiu o emprego!" Maria está muito feliz. Na segunda-feira ela começa a trabalhar.`,
    duration: 3,
    questions: [
      {
        id: 'q1',
        question: 'Woher kommt Maria?',
        options: ['Aus Deutschland', 'Aus Spanien', 'Aus Italien', 'Aus Frankreich'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Was macht Maria jeden Morgen?',
        options: ['Sie geht arbeiten', 'Sie trinkt Kaffee und liest Zeitung', 'Sie lernt Deutsch', 'Sie schreibt E-Mails'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Was sucht Maria?',
        options: ['Eine Wohnung', 'Einen Deutschkurs', 'Einen Job', 'Einen Freund'],
        correctAnswer: 2
      },
      {
        id: 'q4',
        question: 'Wie lange lernt Maria schon Deutsch?',
        options: ['Drei Monate', 'Ein Jahr', 'Zwei Jahre', 'Fünf Jahre'],
        correctAnswer: 2
      },
      {
        id: 'q5',
        question: 'Wann fängt Maria an zu arbeiten?',
        options: ['Sofort', 'Am Montag', 'In einer Woche', 'Am Wochenende'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'story-a2-002',
    title: 'Im Supermarkt',
    level: 'A2',
    category: 'einkaufen',
    text: `Heute ist Samstag. Anna möchte kochen. Sie geht in den Supermarkt.

Zuerst braucht sie Gemüse. Sie nimmt Tomaten, Gurken und Paprika. Dann geht sie zur Fleischtheke. "Ich hätte gerne 500 Gramm Rinderhack, bitte", sagt Anna. Der Verkäufer wiegt das Fleisch und gibt es ihr.

Anna braucht auch Milch, Eier und Brot. Sie findet alles schnell. An der Kasse zahlt sie mit ihrer Karte. Das kostet insgesamt 23,50 Euro.

"Schönes Wochenende!", sagt die Kassiererin. "Danke, gleichfalls!", antwortet Anna.

Zu Hause kocht Anna eine leckere Bolognese. Ihre Familie ist sehr zufrieden.`,
    translation: `Hoje é sábado. Anna quer cozinhar. Ela vai ao supermercado.

Primeiro ela precisa de legumes. Ela pega tomates, pepinos e pimentões. Depois vai ao balcão de carne. "Eu gostaria de 500 gramas de carne moída, por favor", diz Anna. O vendedor pesa a carne e a entrega.

Anna também precisa de leite, ovos e pão. Ela encontra tudo rapidamente. No caixa ela paga com o cartão. Custa no total 23,50 euros.

"Tenha um bom fim de semana!", diz a caixa. "Obrigado, igualmente!", responde Anna.

Em casa Anna cozinha um delicioso molho à bolonhesa. Sua família está muito satisfeita.`,
    duration: 2,
    questions: [
      {
        id: 'q1',
        question: 'Wann geht Anna in den Supermarkt?',
        options: ['Am Sonntag', 'Am Samstag', 'Am Freitag', 'Am Montag'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Was kauft Anna an der Fleischtheke?',
        options: ['Hähnchen', 'Fisch', 'Rinderhack', 'Schweinefleisch'],
        correctAnswer: 2
      },
      {
        id: 'q3',
        question: 'Wie zahlt Anna?',
        options: ['Mit Bargeld', 'Mit Karte', 'Mit Handy', 'Mit Gutschein'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Was kocht Anna zu Hause?',
        options: ['Pizza', 'Suppe', 'Salat', 'Bolognese'],
        correctAnswer: 3
      },
      {
        id: 'q5',
        question: 'Wie viel kostet alles?',
        options: ['15 Euro', '20 Euro', '23,50 Euro', '30 Euro'],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 'story-b1-001',
    title: 'Die Entscheidung',
    level: 'B1',
    category: 'alltag',
    text: `Thomas arbeitet seit fünf Jahren bei einer großen Firma in München. Er ist zufrieden mit seinem Job, aber er hat einen Traum: Er möchte sein eigenes Restaurant eröffnen.

Eines Abends erzählt er seiner Frau Lena von seinem Plan. "Ich weiß nicht, ob ich den sicheren Job aufgeben soll", sagt Thomas. Lena antwortet: "Wenn es dein Traum ist, solltest du es versuchen. Wir können das schaffen zusammen!"

Thomas denkt lange nach. Er hat Angst, aber er hat auch Lena, die ihn unterstützt. Deshalb entscheidet er sich, den Schritt zu wagen.

Sechs Monate später eröffnet Thomas sein Restaurant. Es ist nicht einfach, aber er arbeitet hart. Die Kunden kommen, weil das Essen gut ist. Heute ist Thomas glücklich. Er hat keine Angst mehr – nur Spaß an seiner Arbeit.

"Wenn man einen Traum hat, muss man ihn verfolgen", sagt Thomas. "Aber man braucht Menschen, die einen unterstützen."`,
    translation: `Thomas trabalha há cinco anos em uma grande empresa em Munique. Ele está satisfeito com seu emprego, mas tem um sonho: quer abrir seu próprio restaurante.

Uma noite ele conta à sua esposa Lena sobre seu plano. "Não sei se devo deixar meu emprego seguro", diz Thomas. Lena responde: "Se é seu sonho, deve tentar. Nós conseguimos juntos!"

Thomas pensa por muito tempo. Ele tem medo, mas também tem Lena, que o apoia. Por isso decide dar o passo.

Seis meses depois Thomas abre seu restaurante. Não é fácil, mas ele trabalha duro. Os clientes vêm porque a comida é boa. Hoje Thomas está feliz. Ele não tem mais medo – só se diverte com seu trabalho.

"Quando se tem um sonho, deve-se persegui-lo", diz Thomas. "Mas precisa de pessoas que o apoiem."`,
    duration: 4,
    questions: [
      {
        id: 'q1',
        question: 'Was ist Thomas\' Traum?',
        options: ['Ein Haus zu bauen', 'Sein eigenes Restaurant zu eröffnen', 'Eine Weltreise zu machen', 'Manager zu werden'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Warum zögert Thomas?',
        options: ['Er hat kein Geld', 'Er hat Angst, seinen sicheren Job aufzugeben', 'Seine Frau ist dagegen', 'Er weiß nicht, wie man kocht'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Was rät Lena Thomas?',
        options: ['Den Job zu behalten', 'Noch zu warten', 'Seinen Traum zu verwirklichen', 'Ein anderes Restaurant zu kaufen'],
        correctAnswer: 2
      },
      {
        id: 'q4',
        question: 'Wann eröffnet Thomas sein Restaurant?',
        options: ['Sofort', 'Nach sechs Monaten', 'Nach einem Jahr', 'Nach zwei Jahren'],
        correctAnswer: 1
      },
      {
        id: 'q5',
        question: 'Was ist das Wichtigste laut Thomas?',
        options: ['Viel Geld zu haben', 'Ein gutes Team zu haben', 'Menschen zu haben, die einen unterstützen', 'Keine Angst zu haben'],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 'story-b1-002',
    title: 'Das Umweltprojekt',
    level: 'B1',
    category: 'umwelt',
    text: `Die Stadt Grünberg hat ein Problem: Es gibt zu viel Verkehr und die Luft ist schlecht. Deshalb startet die Stadt ein neues Projekt.

"Wir wollen eine grüne Stadt werden", erklärt Bürgermeister Müller. "Deshalb bauen wir neue Fahrradwege und verbessern den öffentlichen Nahverkehr."

Viele Bürger sind begeistert. Julia, eine Studentin, organisiert eine Fahrradgruppe. "Jeden Donnerstag fahren wir zusammen zur Universität", sagt sie. "Es ist gut für die Umwelt und macht Spaß."

Auch Schulen machen mit. Die Schüler lernen, wie man Müll trennt und Energie spart. "Kinder verstehen schnell, warum Umweltschutz wichtig ist", sagt eine Lehrerin.

Nach einem Jahr sind die Ergebnisse positiv: 30% mehr Menschen fahren mit dem Fahrrad oder dem Bus. Die Luftqualität ist besser geworden.

"Das Projekt zeigt, dass wir gemeinsam etwas verändern können", sagt der Bürgermeister. "Jeder kann einen Beitrag leisten."`,
    translation: `A cidade de Grünberg tem um problema: há muito trânsito e o ar está ruim. Por isso a cidade inicia um novo projeto.

"Queremos nos tornar uma cidade verde", explica o prefeito Müller. "Por isso construímos novas ciclovias e melhoramos o transporte público."

Muitos cidadãos estão entusiasmados. Julia, uma estudante, organiza um grupo de ciclismo. "Toda quinta-feira pedalamos juntos para a universidade", diz ela. "É bom para o meio ambiente e é divertido."

As escolas também participam. Os alunos aprendem a separar o lixo e economizar energia. "As crianças entendem rapidamente por que a proteção ambiental é importante", diz uma professora.

Depois de um ano os resultados são positivos: 30% mais pessoas andam de bicicleta ou ônibus. A qualidade do ar melhorou.

"O projeto mostra que juntos podemos mudar algo", diz o prefeito. "Todos podem contribuir."`,
    duration: 4,
    questions: [
      {
        id: 'q1',
        question: 'Welches Problem hat die Stadt Grünberg?',
        options: ['Zu wenig Wohnungen', 'Zu viel Verkehr und schlechte Luft', 'Zu viele Touristen', 'Zu hohe Steuern'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Was baut die Stadt?',
        options: ['Neue Straßen', 'Neue Fahrradwege', 'Neue Parkplätze', 'Neue Häuser'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Was macht Julia?',
        options: ['Sie ist Lehrerin', 'Sie arbeitet beim Bürgermeister', 'Sie organisiert eine Fahrradgruppe', 'Sie trennt Müll'],
        correctAnswer: 2
      },
      {
        id: 'q4',
        question: 'Wie oft fährt Julias Gruppe zur Universität?',
        options: ['Jeden Tag', 'Jeden Montag', 'Jeden Donnerstag', 'Jeden Freitag'],
        correctAnswer: 2
      },
      {
        id: 'q5',
        question: 'Wie hat sich die Situation nach einem Jahr verändert?',
        options: ['30% mehr Autos', '30% mehr Menschen fahren Fahrrad oder Bus', 'Nichts hat verändert', 'Die Luft ist schlechter geworden'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'story-a2-003',
    title: 'Am Bahnhof',
    level: 'A2',
    category: 'verkehr',
    text: `Paul möchte seine Freundin in Berlin besuchen. Er steht am Bahnhof und sucht sein Gleis.

Er geht zur Information und fragt: "Entschuldigung, wann fährt der nächste Zug nach Berlin?"
Der Mitarbeiter antwortet: "Der nächste Zug fährt um 14:30 Uhr von Gleis 5."

Paul schaut auf die Uhr. Es ist 14:10 Uhr. Er hat noch 20 Minuten Zeit. Er kauft noch ein Brötchen und eine Flasche Wasser.

Um 14:25 Uhr geht Paul zu Gleis 5. Der Zug kommt pünktlich. Paul steigt ein und sucht seinen Platz. "Platz 23, Wagen 4", liest er auf seinem Ticket.

Die Fahrt dauert zwei Stunden. Paul liest ein Buch und schaut aus dem Fenster. In Berlin wartet schon seine Freundin am Bahnhof. "Schön, dass du da bist!", sagt sie.`,
    translation: `Paul quer visitar sua namorada em Berlim. Ele está na estação e procura sua plataforma.

Ele vai à informação e pergunta: "Com licença, quando parte o próximo trem para Berlim?"
O funcionário responde: "O próximo trem parte às 14:30 da plataforma 5."

Paul olha o relógio. São 14:10. Ele ainda tem 20 minutos. Ele compra um pãozinho e uma garrafa de água.

Às 14:25 Paul vai à plataforma 5. O trem chega pontualmente. Paul entra e procura seu lugar. "Lugar 23, vagão 4", lê ele em sua passagem.

A viagem dura duas horas. Paul lê um livro e olha pela janela. Em Berlim sua namorada já o espera na estação. "Que bom que você chegou!", diz ela.`,
    duration: 3,
    questions: [
      {
        id: 'q1',
        question: 'Wen möchte Paul besuchen?',
        options: ['Seine Eltern', 'Seine Freundin', 'Seinen Bruder', 'Seine Kollegen'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Wohin reist Paul?',
        options: ['Nach München', 'Nach Hamburg', 'Nach Berlin', 'Nach Köln'],
        correctAnswer: 2
      },
      {
        id: 'q3',
        question: 'Wann fährt der Zug?',
        options: ['Um 14:00 Uhr', 'Um 14:30 Uhr', 'Um 15:00 Uhr', 'Um 15:30 Uhr'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Was kauft Paul am Bahnhof?',
        options: ['Eine Zeitung und Kaffee', 'Ein Brötchen und Wasser', 'Ein Buch und Tee', 'Einen Salat und Saft'],
        correctAnswer: 1
      },
      {
        id: 'q5',
        question: 'Wie lange dauert die Fahrt?',
        options: ['Eine Stunde', 'Zwei Stunden', 'Drei Stunden', 'Vier Stunden'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'story-a2-004',
    title: 'Beim Arzt',
    level: 'A2',
    category: 'gesundheit',
    text: `Lisa fühlt sich nicht gut. Sie hat Kopfschmerzen und Fieber. Deshalb macht sie einen Termin beim Arzt.

Im Wartezimmer sitzen viele Patienten. Lisa muss 20 Minuten warten. Dann ruft die Arzthelferin ihren Namen: "Lisa Müller, bitte!"

Die Ärztin untersucht Lisa. Sie hört ihre Lunge ab und misst das Fieber. "Sie haben eine Erkältung", sagt die Ärztin. "Sie müssen viel trinken und sich ausruhen."

Die Ärztin schreibt ein Rezept für Medikamente. Lisa geht zur Apotheke nebenan. Der Apotheker gibt ihr Tabletten und erklärt: "Nehmen Sie dreimal täglich eine Tablette."

Lisa geht nach Hause und legt sich ins Bett. Nach drei Tagen geht es ihr wieder gut.`,
    translation: `Lisa não se sente bem. Ela tem dor de cabeça e febre. Por isso marca uma consulta com o médico.

Na sala de espera estão muitos pacientes. Lisa precisa esperar 20 minutos. Então a assistente chama seu nome: "Lisa Müller, por favor!"

A médica examina Lisa. Ela ausculta seus pulmões e mede a febre. "Você está com um resfriado", diz a médica. "Você precisa beber bastante líquido e descansar."

A médica escreve uma receita para medicamentos. Lisa vai à farmácia ao lado. O farmacêutico lhe dá comprimidos e explica: "Tome um comprimido três vezes ao dia."

Lisa vai para casa e se deita na cama. Depois de três dias ela está bem novamente.`,
    duration: 3,
    questions: [
      {
        id: 'q1',
        question: 'Was hat Lisa?',
        options: ['Bauchschmerzen', 'Kopfschmerzen und Fieber', 'Zahnschmerzen', 'Halsweh'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Wie lange muss Lisa im Wartezimmer warten?',
        options: ['5 Minuten', '10 Minuten', '20 Minuten', '30 Minuten'],
        correctAnswer: 2
      },
      {
        id: 'q3',
        question: 'Was hat Lisa?',
        options: ['Eine Grippe', 'Eine Erkältung', 'Eine Allergie', 'Einen Virus'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Was soll Lisa machen?',
        options: ['Viel Sport machen', 'Viel trinken und sich ausruhen', 'Weiterarbeiten', 'Ins Kino gehen'],
        correctAnswer: 1
      },
      {
        id: 'q5',
        question: 'Wann geht es Lisa wieder gut?',
        options: ['Nach einem Tag', 'Nach drei Tagen', 'Nach einer Woche', 'Nach zwei Wochen'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'story-a2-005',
    title: 'Das neue Restaurant',
    level: 'A2',
    category: 'freizeit',
    text: `Ahmed kommt aus der Türkei und lebt seit zwei Jahren in Deutschland. Er liebt das Kochen. Sein Traum ist ein eigenes Restaurant.

Eines Tages findet er eine kleine Ladenfläche in der Stadtmitte. Die Miete ist nicht zu teuer. Ahmed spricht mit seinem Bankberater und bekommt einen Kredit.

Zwei Monate später eröffnet Ahmed sein Restaurant "Istanbul". Er kocht türkische Spezialitäten: Kebab, Falafel und Baklava. Die Kunden kommen und sind begeistert.

"Das Essen ist fantastisch!", sagt eine Kundin. "Ich komme bestimmt wieder."

Ahmed arbeitet hart, aber er ist glücklich. Sein Traum ist wahr geworden. Er lächelt und sagt: "Wer einen Traum hat, soll ihn verwirklichen."`,
    translation: `Ahmed vem da Turquia e vive há dois anos na Alemanha. Ele ama cozinhar. Seu sonho é ter seu próprio restaurante.

Um dia ele encontra um pequeno espaço comercial no centro da cidade. O aluguel não é muito caro. Ahmed fala com seu consultor bancário e consegue um empréstimo.

Dois meses depois Ahmed abre seu restaurante "Istambul". Ele cozinha especialidades turcas: kebab, falafel e baklava. Os clientes vêm e ficam entusiasmados.

"A comida é fantástica!", diz uma cliente. "Com certeza voltarei."

Ahmed trabalha duro, mas está feliz. Seu sonho se realizou. Ele sorri e diz: "Quem tem um sonho deve realizá-lo."`,
    duration: 3,
    questions: [
      {
        id: 'q1',
        question: 'Woher kommt Ahmed?',
        options: ['Aus Deutschland', 'Aus der Türkei', 'Aus Italien', 'Aus Griechenland'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Was ist Ahmeds Traum?',
        options: ['Ein Haus zu kaufen', 'Ein eigenes Restaurant', 'Eine Reise zu machen', 'Deutsch zu lernen'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Wo ist das Restaurant?',
        options: ['Am Bahnhof', 'In der Stadtmitte', 'Am Flughafen', 'Im Einkaufszentrum'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Was kocht Ahmed?',
        options: ['Italienische Pizza', 'Deutsche Bratwurst', 'Türkische Spezialitäten', 'Chinesisches Essen'],
        correctAnswer: 2
      },
      {
        id: 'q5',
        question: 'Wie fühlt sich Ahmed?',
        options: ['Traurig', 'Gestresst', 'Glücklich', 'Müde'],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 'story-b1-003',
    title: 'Die Jobbewerbung',
    level: 'B1',
    category: 'beruf',
    text: `Sven ist 35 Jahre alt und arbeitet als Ingenieur. Aber er ist unzufrieden mit seinem Job. Die Firma macht Probleme und das Gehalt ist zu niedrig.

Sven entscheidet sich, sich zu bewerben. Er schreibt seinen Lebenslauf neu und aktualisiert seine Unterlagen. "Ich muss mich gut vorbereiten", denkt er.

Er sieht eine interessante Anzeige: "Ingenieur gesucht für innovatives Unternehmen." Sven schreibt sofort eine Bewerbung. Nach zwei Wochen bekommt er eine Einladung zum Vorstellungsgespräch.

Am Tag des Gesprächs trägt Sven einen Anzug. Er ist nervös, aber gut vorbereitet. Die Personalchefin fragt: "Warum wollen Sie Ihre Stelle wechseln?"

Sven antwortet ehrlich: "Ich suche neue Herausforderungen und möchte mich weiterentwickeln."

Nach dem Gespräch wartet Sven gespannt. Drei Tage später klingelt das Telefon: "Wir möchten Ihnen die Stelle anbieten." Sven freut sich riesig. Er hat den Job bekommen!`,
    translation: `Sven tem 35 anos e trabalha como engenheiro. Mas está insatisfeito com seu emprego. A empresa tem problemas e o salário é muito baixo.

Sven decide se candidatar a outro emprego. Ele reescreve seu currículo e atualiza seus documentos. "Preciso me preparar bem", pensa.

Ele vê um anúncio interessante: "Engenheiro procurado para empresa inovadora." Sven escreve imediatamente uma candidatura. Depois de duas semanas recebe um convite para entrevista.

No dia da entrevista Sven veste um terno. Está nervoso, mas bem preparado. A gerente de RH pergunta: "Por que você quer mudar de emprego?"

Sven responde honestamente: "Busco novos desafios e quero me desenvolver profissionalmente."

Depois da entrevista Sven espera ansiosamente. Três dias depois o telefone toca: "Gostaríamos de oferecer a vaga para você." Sven fica muito feliz. Conseguiu o emprego!`,
    duration: 4,
    questions: [
      {
        id: 'q1',
        question: 'Warum ist Sven unzufrieden mit seinem Job?',
        options: ['Die Kollegen sind unfreundlich', 'Der Weg ist zu weit', 'Das Gehalt ist zu niedrig und die Firma hat Probleme', 'Er hat zu viel Arbeit'],
        correctAnswer: 2
      },
      {
        id: 'q2',
        question: 'Was macht Sven zuerst?',
        options: ['Er kündigt sofort', 'Er schreibt seinen Lebenslauf neu', 'Er ruft die Firma an', 'Er geht zum Arbeitsamt'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Wann bekommt Sven die Einladung zum Gespräch?',
        options: ['Nach einer Woche', 'Nach zwei Wochen', 'Nach einem Monat', 'Sofort'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Was trägt Sven zum Vorstellungsgespräch?',
        options: ['Einen Anzug', 'Eine Jeans', 'Einen Pullover', 'Ein T-Shirt'],
        correctAnswer: 0
      },
      {
        id: 'q5',
        question: 'Warum will Sven die Stelle wechseln?',
        options: ['Er will mehr Geld', 'Er hasst seinen Chef', 'Er sucht neue Herausforderungen', 'Er will umziehen'],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 'story-b1-004',
    title: 'Das Abenteuer Wandern',
    level: 'B1',
    category: 'freizeit',
    text: `Laura und Mark sind ein Paar aus Hamburg. Sie lieben die Natur und entscheiden sich für einen Wanderurlaub in den Alpen.

"Wir sollten uns gut vorbereiten", sagt Mark. Er kauft Wanderkarten und plant die Route. Laura besorgt Ausrüstung: Wanderschuhe, einen Rucksack und eine Regenjacke.

Im Urlaub wandern sie jeden Tag durch die Berge. Die Landschaft ist wunderschön. Sie sehen Kühe auf den Wiesen und hören das Läuten der Glocken.

Am dritten Tag werden die Wolken dunkel. "Es wird regnen", sagt Laura. Schnell suchen sie eine Berghütte. Gerade als sie ankommen, beginnt es stark zu regnen.

In der Hütte trinken sie Tee und unterhalten sich mit anderen Wanderern. "Das Wetter in den Bergen ist unberechenbar", sagt ein alter Bergsteiger. "Aber die Erfahrung ist trotzdem schön."

Am nächsten Tag scheint wieder die Sonne. Laura und Mark fahren glücklich nach Hause. "Das war ein tolles Abenteuer", sagen sie.`,
    translation: `Laura e Mark são um casal de Hamburgo. Eles amam a natureza e decidem fazer férias de caminhada nos Alpes.

"Devemos nos preparar bem", diz Mark. Ele compra mapas de trilha e planeja a rota. Laura compra equipamento: botas de caminhada, uma mochila e uma jaqueta de chuva.

Nas férias eles caminham todos os dias pelas montanhas. A paisagem é linda. Veem vacas nos prados e ouvem o som dos sinos.

No terceiro dia as nuvens ficam escuras. "Vai chover", diz Laura. Rapidamente procuram um refúgio de montanha. Assim que chegam, começa a chover forte.

No refúgio bebem chá e conversam com outros caminhantes. "O tempo nas montanhas é imprevisível", diz um velho alpinista. "Mas a experiência ainda assim é bonita."

No dia seguinte o sol brilha novamente. Laura e Mark voltam felizes para casa. "Foi uma grande aventura", dizem eles.`,
    duration: 4,
    questions: [
      {
        id: 'q1',
        question: 'Woher kommen Laura und Mark?',
        options: ['Aus München', 'Aus Berlin', 'Aus Hamburg', 'Aus Köln'],
        correctAnswer: 2
      },
      {
        id: 'q2',
        question: 'Wohin fahren sie in den Urlaub?',
        options: ['An die See', 'In die Alpen', 'Ins Ausland', 'In einen Park'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Was passiert am dritten Tag?',
        options: ['Sie verlieren sich', 'Es beginnt zu regnen', 'Mark wird krank', 'Sie finden einen Schatz'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Wo warten Laura und Mark auf besseres Wetter?',
        options: ['Im Hotel', 'Im Zelt', 'In einer Berghütte', 'Im Auto'],
        correctAnswer: 2
      },
      {
        id: 'q5',
        question: 'Was sagt der alte Bergsteiger?',
        options: ['Man sollte nie wandern', 'Das Wetter in den Bergen ist unberechenbar', 'Die Berge sind zu gefährlich', 'Man braucht bessere Ausrüstung'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'story-b1-005',
    title: 'Die deutsche Kultur',
    level: 'B1',
    category: 'kultur',
    text: `Carlo kommt aus Italien und macht ein Auslandssemester in Deutschland. Er ist gespannt auf die deutsche Kultur.

Am ersten Tag bemerkt er etwas Seltsames: Die Deutschen stehen an der Ampel, auch wenn keine Autos kommen. "Warum wartet ihr?", fragt er seinen deutschen Freund Klaus. "In Italien gehen wir einfach!"

Klaus lacht: "Das ist typisch deutsch. Wir halten uns an die Regeln, auch wenn niemand kontrolliert." Carlo findet das interessant.

Ein anderes Thema ist die Pünktlichkeit. Carlo kommt 10 Minuten zu spät zu einer Verabredung. Seine deutschen Freunde warten schon. "Entschuldigung!", sagt Carlo. "In Italien ist das normal."

"Pünktlichkeit ist sehr wichtig in Deutschland", erklärt Klaus. "Wenn man zu spät kommt, ist das unhöflich."

Nach einigen Monaten gewöhnt Carlo sich an die deutschen Gepflogenheiten. Er lernt: Jede Kultur hat ihre eigenen Regeln. "Ich finde es gut, dass die Deutschen so organisiert sind", sagt er am Ende seines Semesters.`,
    translation: `Carlo vem da Itália e faz um semestre no exterior na Alemanha. Ele está curioso sobre a cultura alemã.

No primeiro dia ele nota algo estranho: Os alemães ficam no sinal, mesmo quando não vêm carros. "Por que vocês esperam?", pergunta a seu amigo alemão Klaus. "Na Itália simplesmente atravessamos!"

Klaus ri: "Isso é típico alemão. Seguimos as regras, mesmo quando ninguém controla." Carlo acha isso interessante.

Outro tema é a pontualidade. Carlo chega 10 minutos atrasado para um encontro. Seus amigos alemães já estão esperando. "Desculpa!", diz Carlo. "Na Itália isso é normal."

"Pontualidade é muito importante na Alemanha", explica Klaus. "Quando se chega atrasado, é indelicado."

Depois de alguns meses Carlo se acostuma com os costumes alemães. Ele aprende: Cada cultura tem suas próprias regras. "Acho bom que os alemães sejam tão organizados", diz ele no final do semestre.`,
    duration: 4,
    questions: [
      {
        id: 'q1',
        question: 'Woher kommt Carlo?',
        options: ['Aus Deutschland', 'Aus Italien', 'Aus Spanien', 'Aus Frankreich'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        question: 'Was macht Carlo in Deutschland?',
        options: ['Er arbeitet', 'Er macht ein Auslandssemester', 'Er macht Urlaub', 'Er besucht Verwandte'],
        correctAnswer: 1
      },
      {
        id: 'q3',
        question: 'Was ist typisch deutsch laut Klaus?',
        options: ['Immer in Eile zu sein', 'Sich an die Regeln zu halten', 'Laut zu sprechen', 'Spät zu kommen'],
        correctAnswer: 1
      },
      {
        id: 'q4',
        question: 'Wie spät kommt Carlo zur Verabredung?',
        options: ['Pünktlich', '5 Minuten zu spät', '10 Minuten zu spät', '30 Minuten zu spät'],
        correctAnswer: 2
      },
      {
        id: 'q5',
        question: 'Was findet Carlo am Ende über die Deutschen?',
        options: ['Sie sind zu streng', 'Sie sind gut organisiert', 'Sie sind unhöflich', 'Sie sind zu laut'],
        correctAnswer: 1
      }
    ]
  }
];
